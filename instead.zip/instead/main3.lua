--$Name:Тестовое окружение$
--$Version: 0.0.1$
--$Author: Вячеслав Добранов$

std.SOURCES_DIRS = { 'story', '.' }
std.phrase_show = false       -- В диалогах не выводить то, что выбрано
require "parser/mp-ru"
require "fmt"
require "autotheme"
-- mp.errhints = false
game.dsc = false

-- include "dictionary"          -- Дополнительный словарь
include "msgs"                -- Переопределённые библиотечные сообщения
include "properties"          -- Свойства объектов
include "verbs"               -- Глаголы
include "verb_mapping"        -- Требуемые свойства объектов для каждого глагола
include "functions"           -- Кастомные функции
include "classes"             -- Классы
include "story/protagonists"  -- Протагонисты
-- include "story/prologue"      -- Пролог
include "story/test"          -- Тестовая комната

mp.undo = 20
mp.detailed_inv = true
mp.msg.TITLE_TURNS = ""
instead.notitle = false -- enable status
--instead.get_title = 3
mp.autohelp_limit=1
mp.compl_thresh=3
mp.togglehelp=false
mp.autocompl=true
mp.lev_thresh=2
mp.clear_on_move = false;

mp.tick_duration = 30; -- Длительность одного хода в секундах

function init()
--    change_pl(prologue_character)
   change_pl(test_character)
	-- move('ring', prologue_character)
	-- move('phone', prologue_character)
end

