-- Свойства объектов:
--	Размер
--	Вес
-- 	Звук
-- 	Запах
-- 	Близость к ГГ

const 'SIZE' ({
	TINY = 1,		-- 0.01 m
	SMALL = 2,		-- 0.1 m
	MEDIUM = 3,		-- 1 m
	BIG = 4,		-- 10 m
	LARGE = 5,		-- 100 m
	HUGE = 6,		-- 1 km
	ENORMOUS = 7,	-- +∞
})

const 'WEIGHT' ({
	WEIGHTLESS = 1,	-- 0-1 kg
	LIGHT = 2,	-- 1-10 kg
	MEDIUM = 3,		-- 10-50 kg
	HEAVY = 4,		-- 50-100 kg
	HEAVIER = 5,	-- 100-1000 kg
	TOOHEAVY = 6,	-- > 1000 kg
})

const 'SOUND' ({
	QUIET = 1,		-- Беззвучный
	AUDIBLE = 2,	-- Негромкий
	LOUD = 3,		-- Громкий
})

const 'SMELL' ({
	NONSMELLY = 1,	-- без запаха
	SMELLY = 2,		-- с запахом
})

const 'PROXIMITY' ({
	AROUND = 1,		-- вокруг ГГ
	CLOSE = 2,		-- на расстоянии вытянутой руки (check_touch == true)
	NEAR = 3,		-- < 10 m
	REACHABLE = 4,	-- < 100 m
	FAR = 5,		-- < 1 km
	TOOFAR = 6		-- > 1 km
})