-- Кастомные функции

-- Функция проверки — соответствуют ли свойства объекта введённому глаголу
declare 'check_verb' (function (s, ev)
	-- Если глагола нет в verb_map, возвращаем управление парсеру
	if not verb_map[ev] or s == here() then
		return false;
	end
	local attr = 0;
	-- Если глагол требует (новые) атрибуты, есть ли у объекта хоть один из них (если нет, сразу true)
	-- Например, для Drink должен быть drinkable
	local attributes_map = verb_map[ev].Attributes;
	if attributes_map and #attributes_map > 0 then 
		for k, v in pairs(attributes_map) do
			if s:has(v) then
				attr = true;
			end
		end
	else
		attr = true;
	end

	-- Определяем нижнюю и верхнюю границы диапазона такого-то свойства для данного глагола
	local size_map = verb_map[ev].Size;
	local weight_map = verb_map[ev].Weight;
	local sound_map = verb_map[ev].Sound;
	local smell_map = verb_map[ev].Smell;
	local proximity_map = verb_map[ev].Proximity;
	local size_min = 0; local size_max = 0;
	local weight_min = 0; local weight_max = 0;
	local sound_min = 0; local sound_max = 0;
	local smell_min = 0; local smell_max = 0;
	local proximity_min = 0; local proximity_max = 0;

	local min = function (map)
		if map then 
			for i, v in ipairs(map) do
				if v == 1 then 
					return i
				end
			end
		else
			return 1
		end
	end

	local max = function (map, up)
		if map then
			for i = #map, 1, -1 do
				if map[i] == 1 then
					return i
				end
			end
		else
			return up
		end
	end

	size_min = min(size_map); size_max = max(size_map, 7);
	weight_min = min(weight_map); weight_max = max(weight_map, 6);
	sound_min = min(sound_map); sound_max = max(sound_map, 3);
	smell_min = min(smell_map); smell_max = max(smell_map, 2);
	proximity_min = min(proximity_map); proximity_max = max(proximity_map, 6);
	if me().stat then
		pn("> " .. ev .. " : " .. tostring(mp.first) .. " : " .. tostring(mp.second))
		if attributes_map then
			pn ("Attributes do match: " .. tostring(attr));
		end
		if size_map then
			pn ("Required size: " .. size_min .. "‒" .. size_max .. ". Object’s size: " .. s.size);
		end
		if weight_map then
			pn ("Required weight: " .. weight_min .. "‒" .. weight_max .. ". Object’s weight: " .. s.weight);
		end
		if sound_map then
			pn ("Required sound: " .. sound_min .. "‒" .. sound_max .. ". Object’s sound: " .. s.sound);
		end
		if smell_map then
			pn ("Required smell: " .. smell_min .. "‒" .. smell_max .. ". Object’s smell: " .. s.smell);
		end
		if proximity_map then
			pn ("Required proximity: " .. proximity_min .. "‒" .. proximity_max .. ". Object’s proximity: " .. s.proximity);
		end
		pn();
	end

	if attr == 0 then
		return p(verb_map[ev].NoMsg or mp.msg.IMPOSSIBLE);
	end
	if s.proximity < proximity_min and s.proximity == 1 then
		return p(verb_map[ev].AroundMsg or mp.msg.AROUND);
	end
	if s.proximity < proximity_min then
		return p(verb_map[ev].TooCloseMsg or mp.msg.TOOCLOSE);
	end
	if s.proximity > proximity_max then
		if s.weight > weight_max then
			if s.size > size_max then
				return p(verb_map[ev].TooFarHeavyBigMsg or mp.msg.TOOFARHEAVYBIG);
			elseif s.size < size_min then
				return p(verb_map[ev].TooFarHeavySmallMsg or mp.msg.TOOFARHEAVYSMALL);
			else
				return p(verb_map[ev].TooFarHeavyMsg or mp.msg.TOOFARHEAVY);
			end
		elseif s.weight < weight_min then
			if s.size > size_max then
				return p(verb_map[ev].TooFarLightBigMsg or mp.msg.TOOFARLIGHTBIG);
			elseif s.size < size_min then
				return p(verb_map[ev].TooFarLightSmallMsg or mp.msg.TOOFARLIGHTSMALL);
			else
				return p(verb_map[ev].TooFarLightMsg or mp.msg.TOOFARLIGHT);
			end
		else
			if s.size > size_max then
				return p(verb_map[ev].TooFarBigMsg or mp.msg.TOOFARBIG);
			elseif s.size < size_min then
				return p(verb_map[ev].TooFarSmallMsg or mp.msg.TOOFARSMALL);
			else
				return p(verb_map[ev].TooFarMsg or mp.msg.TOOFAR);
			end
		end
	end
	if s.weight > weight_max then
		if s.size > size_max then
			return p(verb_map[ev].TooHeavyBigMsg or mp.msg.TOOHEAVYBIG);
		elseif s.size < size_min then
			return p(verb_map[ev].TooHeavySmallMsg or mp.msg.TOOHEAVYSMALL);
		else
			return p(verb_map[ev].TooHeavyMsg or mp.msg.TOOHEAVY);
		end
	elseif s.weight < weight_min then
		if s.size > size_max then
			return p(verb_map[ev].TooLightBigMsg or mp.msg.TOOLIGHTBIG);
		elseif s.size < size_min then
			return p(verb_map[ev].TooLightSmallMsg or mp.msg.TOOLIGHTSMALL);
		else
			return p(verb_map[ev].TooLightMsg or mp.msg.TOOLIGHT);
		end
	end
	if s.size < size_min then
		return p(verb_map[ev].TooSmallMsg or mp.msg.TOOSMALL);
	end
	if s.size > size_max then
		return p(verb_map[ev].TooBigMsg or mp.msg.TOOBIG);
	end
	if s.smell < smell_min then
		return p(verb_map[ev].NoSmellMsg);
	end
	if s.sound < sound_min then
		return p(verb_map[ev].NoSoundMsg);
	end

	return false;

	-- -- Если категория не пустая, возвращаем из verb_map 1 или 0 для соответствующего свойства, иначе сразу true
	-- local size = (verb_map[ev].Size and #verb_map[ev].Size > 0 and verb_map[ev].Size[s.size] or true);
	-- local weight = (verb_map[ev].Weight and #verb_map[ev].Weight > 0 and verb_map[ev].Weight[s.weight] or true);
	-- local sound = (verb_map[ev].Sound and #verb_map[ev].Sound > 0 and verb_map[ev].Sound[s.sound] or true);
	-- local smell = (verb_map[ev].Smell and #verb_map[ev].Smell > 0 and verb_map[ev].Smell[s.smell] or true);
	-- local proximity = (verb_map[ev].Proximity and #verb_map[ev].Proximity > 0 and verb_map[ev].Proximity[s.proximity] or true);
	-- -- Если хоть одна из проверок не прошла, возвращаем сообщение о неудаче
	-- if (attr == 0 or size == 0 or weight == 0 or sound == 0 or smell == 0 or proximity == 0) then
	-- 	return p(verb_map[ev].NoMsg);
	-- end
	-- return false;
end)

-- Функция сокращения для подстановки времени (нст, прш)
mp.shortcut.time = function ()
	return me().time
end

-- Функция сокращения для подстановки в зависимости от текущего времени
mp.shortcut.if_time = function (hint)
	local w = mp.str_split(hint, ",")
	local time = w[1]
	if time == me().time then
		return w[2] or ''
	end
	return w[3] or ''
end

-- Функция вывода времени текстом
declare 'time_txt' (function (h,m)
	if h == 23 then
		if m == 45 then
			return "без четверти полночь";
		elseif m == 46 then
			return "без четырнадцати минут полночь";
		elseif m == 47 then
			return "без тринадцати минут полночь";
		elseif m == 48 then
			return "без двенадцати минут полночь";
		elseif m == 49 then
			return "без одиннадцати минут полночь";
		elseif m == 50 then
			return "без десяти минут полночь";
		elseif m == 51 then
			return "без девяти минут полночь";
		elseif m == 52 then
			return "без восьми минут полночь";
		elseif m == 53 then
			return "без семи минут полночь";
		elseif m == 54 then
			return "без шести минут полночь";
		elseif m == 55 then
			return "без пяти минут полночь";
		elseif m == 56 then
			return "без четырёх минут полночь";
		elseif m == 57 then
			return "без трёх минут полночь";
		elseif m == 58 then
			return "без двух минут полночь";
		elseif m == 59 then
			return "без одной минуты полночь";
		else
			return "_";
		end
	elseif h == 0 then
		if m == 0 then
			return "полночь";
		elseif m == 1 then
			return "одну минуту пополуночи";
		elseif m == 2 then
			return "две минуты пополуночи";
		elseif m == 3 then
			return "три минуты пополуночи";
		elseif m == 4 then
			return "четыре минуты пополуночи";
		elseif m == 5 then
			return "пять минут пополуночи";
		elseif m == 6 then
			return "шесть минут пополуночи";
		elseif m == 7 then
			return "семь минут пополуночи";
		elseif m == 8 then
			return "восемь минут пополуночи";
		elseif m == 9 then
			return "девять минут пополуночи";
		elseif m == 10 then
			return "десять минут пополуночи";
		elseif m == 11 then
			return "одиннадцать минут пополуночи";
		elseif m == 12 then
			return "двенадцать минут пополуночи";
		elseif m == 13 then
			return "тринадцать минут пополуночи";
		elseif m == 14 then
			return "четырнадцать минут пополуночи";
		elseif m == 15 then
			return "четверть первого ночи";
		elseif m == 16 then
			return "шестнадцать минут первого";
		elseif m == 17 then
			return "семнадцать минут первого";
		elseif m == 18 then
			return "восемнадцать минут первого";
		elseif m == 19 then
			return "девятнадцать минут первого";
		elseif m == 20 then
			return "двадцать минут первого";
		else
			return "_";
		end
	else
		return "_";
	end
end)

-- Функция проверки, содержит ли таблица значение
declare 'contains' (function (table, val)
   for i=1,#table do
      if table[i] == val then 
         return true
      end
   end
   return false
end)

global 'checked_needs' ({});
-- Функция определения текущей потребности персонажа
declare 'current_need' (function (n,d)
	-- Если в функцию не передана потребность, начинаем определение с той, которая указана основной
	if d == nil then
		d = n.needs[n.main_need];
	end;
	-- Если потребность не удовлетворена, проверяем потребности, от которых она зависит
	if not d.gist(n) then
		for k, v in pairs (d.obstacles) do
			-- Проверяем потребность только, если она ещё не проверена, иначе возможен цикл, если две потребности находятся друг у друга в obstacles
			if not contains(checked_needs, n.needs[v]) then
				table.insert(checked_needs, n.needs[v]);
				if not n.needs[v].gist(n) then
					d = current_need(n,n.needs[v]);
				end
			end
		end
	end
	checked_needs = {};
	return d;
end)

-- Функция обнуления счётчиков у всех не указанных потребностей
declare 'reset_cooldowns' (function (n,d)
	for k, v in pairs (n.needs) do
		if n.needs[k] ~= d then
			n.needs[k].reaction.cooldown[1] = 0;
		end
	end
end)

-- Функция вывода реакции персонажа в зависимости от потребности
declare 'current_need_reaction' (function (n,d)
	-- cooldown — таблица: {счётчик, шаг}
	local c = d.reaction.cooldown;
	pn(c[1]);
	c = (type(c) == "function" and c() or c);
	-- Если счётчик = 0, выводим реакцию
	if c[1] == 0 then
		d.reaction.func(n);
	end
	if c[1] < c[2] then
		c[1] = c[1] + 1
		return
	end
	c[1] = 0;
end)

-- Зонтичная функция для обработки потребностей персонажа и вывода соответствующей реакции
declare 'daemon_of_needs' (function (c)
	local d = current_need(c);
	reset_cooldowns(c,d);
	current_need_reaction(c,d);
end)








-- Замена библиотечных функций

-- Для проверки на касание исключить случай, когда контейнер, в котором находится игрок, — открыт
local function check_persist(w)
	if not w:has 'persist' then
		return false
	end
	if not w.found_in then
		return true
	end
	local _, v = std.call(w, 'found_in')
	return v
end

function std.obj:access()
	local plw = {}
	if std.me():where() == self then
		return true
	end

	if self:has 'persist' then
		if not self.found_in then
			return true
		end
		local _, v = std.call(self, 'found_in')
		return v
	end
	if mp.scope:lookup(self) then
		return true
	end
	mp:trace(std.me(), function(v)
--		if v:has 'concealed' then
--			return nil, false
--		end
		plw[v] = true
							----------------------
		if v:has 'container' and not v:has 'open' then -- or v:has 'supporter' then
							----------------------
			return nil, false
		end
	end)
	return mp:trace(self, function(v)
--		if v:has 'concealed' then
--			return nil, false
--		end
		if check_persist(v) then
			return true
		end
		if plw[v] then
			return true
		end
		if v:has 'container' and not v:has 'open' then
			return nil, false
		end
	end)
end

-- Зачем действиям Listen, Talk, Tell, Ask, Answer, Smell проверка на касание?
function mp:Listen(w)
	-- if mp:check_touch() then
	-- 	return
	-- end
	return false
end

function mp:Smell(w)
	-- if mp:check_touch() then
	-- 	return
	-- end
	return false
end

function mp:Talk(w)
	if mp:check_touch() then
		return
	end
	local r, v = mp:runorval(w, 'talk_to')
	if v then
		if r then
			walkin(r)
		end
		return
	end
	if w == std.me() then
		mp:message 'Talk.SELF'
		return
	end
	if mp:runmethods('life', 'Talk', w) then
		return
	end
	return false
end

function mp:Tell(w, t)
	-- if mp:check_touch() then
	-- 	return
	-- end
	if #self.vargs == 0 then
		mp:message 'Tell.EMPTY'
		return
	end
	if w == std.me() then
		mp:message 'Tell.SELF'
		return
	end
	if mp:runmethods('life', 'Tell', w, t) then
		return
	end
	return false
end

function mp:Ask(w, t)
	-- if mp:check_touch() then
	-- 	return
	-- end
	if #self.vargs == 0 then
		mp:message 'Ask.EMPTY'
		return
	end
	if w == std.me() then
		mp:message 'Ask.SELF'
		return
	end
	if mp:runmethods('life', 'Ask', w, t) then
		return
	end
	return false
end

function mp:Answer(w, t)
	-- if mp:check_touch() then
	-- 	return
	-- end
	if #self.vargs == 0 then
		mp:message 'Answer.EMPTY'
		return
	end
	if w == std.me() then
		mp:message 'Answer.SELF'
		return
	end
	if mp:runmethods('life', 'Answer', w, t) then
		return
	end
	return false
end

-- Добавление в действие передачи проверки на worn и попытка снять объект, если он надет (по аналогии с Insert, например)
function mp:Give(w, wh)
	if mp:check_touch() then
		return
	end
	if mp:check_held(w) then
		return
	end
	-------------------------
	if mp:check_worn(w) then
		return
	end
	-------------------------
	if wh == std.me() then
		mp:message 'Give.MYSELF'
		return
	end
	if mp:runmethods('life', 'Give', wh, w) then
		return
	end
	if mp:check_no_live(wh) then
		return
	end
	return false
end

-- По умолчанию реакция на Пить — Drink.IMPOSSIBLE. Выравниваю с реакцией на Есть
function mp:after_Drink(w)
	mp:message 'Drink.DRINK'
end

-- Если игрок находится в чём-то, сначала попытаться выйти оттуда
-- function mp:before_Walk(w)
-- 	if std.me():where() ~= std.here() and std.me():where() ~= w then
-- 		pn("(сначала покинув {#where/вн})")
-- 		self:subaction('Exit', std.me():where())
-- 		-- self:xaction('Walk', w)
-- 		return
-- 	end
-- 	return false
-- end
function mp:Walk(w)
	if mp:check_touch() then
		return
	end
	if w == std.me():where() then
		mp:message 'Walk.ALREADY'
		return
	end

	if seen(w, std.me()) then
		mp:message 'Walk.INV'
		return
	end
----------------------------------------------
	if std.me():where() ~= std.here() then
		mp:message 'Enter.EXITBEFORE'
		return
	end
----------------------------------------------
	return false
end

-- Отключение вывода в заголовок сцены, где ГГ находится. Например, «(в машине)»
function std.obj:scene()
	local s = self
	local sc = mp:visible_scope(s)
	local title = iface:title(std.titleof(sc))
	-- if s ~= sc then
	-- 	local r = std.call(std.me():where(), "title")
	-- 	title = title .. ' '..mp.fmt("(".. (r or mp:mesg('TITLE_INSIDE')) .. ")")
	-- end
	return title
end

-- Для описания содержимого вывод с учётом времени
mp.msg.Exam.CONTENT = function(w, oo)
	local single = #oo == 1 and not oo[1]:hint 'plural'
	if std.me():where() == w or std.here() == w then
		if false then
		------------------------------------------------------------------------------
			-- if single then
			-- 	local hint = oo[1]:gram().hint
				p ("Там ",mp.mrd:word('находиться/' .. hint .. ', ' .. me().time), " ")
				-- p "Здесь находится"
			-- else
			-- 	p "Там находились"
			-- 	-- p "Здесь находятся"
			-- end
			mp:multidsc(oo)
		------------------------------------------------------------------------------
		else
		--------------------------------------------
			p "{#Me} {#word/видеть,#me,#time} {#if_time/нст,здесь,там}";	
			-- p "{#Me} {#word/видеть,#me,нст} там";
			mp:multidsc(oo, 'вн')
		--------------------------------------------
		end
		p "."
		return
	end
	if w:has 'supporter' then
		mp:pnoun (w, "На {#first/пр,2}")
	else
		mp:pnoun (w, "В {#first/пр,2}")
	end
	----------------------------------------------------------------------
	if single then
		local hint = oo[1]:gram().hint
        p (" ",mp.mrd:word('находиться/' .. hint .. ', ' .. me().time), " ")
		-- p "находится"
	else
		p (" {#if_time/нст,находятся,находились} ")
		-- 	p "находились"
	-- 	-- p "находятся"
	end
	----------------------------------------------------------------------
	mp:multidsc(oo)
	p "."
end

-- Добавление обработки нового сокращения: #time
function mp.str_strip(str)
	return std.strip(str)
end
function mp.str_split(str, delim)
	local a = std.split(str, delim)
	for k, _ in ipairs(a) do
		a[k] = mp.str_strip(a[k])
	end
	return a
end
function mp.hint_append(hint, h)
	if h == "" or not h then return hint end
	if hint == "" or not hint then return h end
	return hint .. ',' .. h
end
function mp.shortcut.word(hint)
	local w = mp.str_split(hint, ",")
	if #w == 0 then
		return hint
	end
	local verb = w[1]
	table.remove(w, 1)
	hint = ''
	for _, k in ipairs(w) do
		if k == '#first' then
			hint = mp.hint_append(hint, mp.first_hint)
		elseif k == '#second' then
			hint = mp.hint_append(hint, mp.second_hint)
		--------------------------------------------
		elseif k == '#time' then
			hint = mp.hint_append(hint, me().time)
		--------------------------------------------
		elseif k:find("#", 1, true) == 1 then
			local ob = mp:shortcut_obj(k)
			if not ob then
				std.err("Wrong shortcut word: "..k, 2)
			end
			hint = mp.hint_append(hint, ob:gram().hint)
		else
			hint = mp.hint_append(hint, k)
		end
	end
	local t = mp.mrd:noun(verb .. '/' .. hint)
	return t
end