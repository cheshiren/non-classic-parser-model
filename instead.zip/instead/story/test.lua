-- Тестовое окружение

Test_Room = Class ({
	dsc = function (s)
		p("Выходы: ")
		if s.n_to then p(_'@n_to'.word .. " "); end;
		if s.ne_to then p(_'@ne_to'.word .. " "); end;
		if s.e_to then p(_'@e_to'.word .. " "); end;
		if s.se_to then p(_'@se_to'.word .. " "); end;
		if s.s_to then p(_'@s_to'.word .. " "); end;
		if s.sw_to then p(_'@sw_to'.word .. " "); end;
		if s.w_to then p(_'@w_to'.word .. " "); end;
		if s.nw_to then p(_'@nw_to'.word .. " "); end;
		if s.d_to then p(_'@d_to'.word .. " "); end;
		if s.u_to then p(_'@u_to'.word .. " "); end;
		if s.in_to then p(_'@in_to'.word .. " "); end;
		if s.out_to then p(_'@out_to'.word .. " "); end;
	end;
}, room);

Test_Object = Class ({
	description = function (s)
		for k, v in pairs(SIZE) do if s.size == v then pn(k .. "(" .. v .. ")") end end
		for k, v in pairs(WEIGHT) do if s.weight == v then pn(k .. "(" .. v .. ")") end end
		for k, v in pairs(SOUND) do if s.sound == v then pn(k .. "(" .. v .. ")") end end
		for k, v in pairs(SMELL) do if s.smell == v then pn(k .. "(" .. v .. ")") end end
		for k, v in pairs(PROXIMITY) do if s.proximity == v then pn(k .. "(" .. v .. ")") end end
	end,
	after_Walk = function (s, w)
		s.proximity = s.proximity - 1;
		return false;
	end;
}, Generic):attr '~concealed';

Test_Room {
	nam = "TestRoom1",
	title = "Тестовая комната 1",
	n_to = 'TestRoom2';
	s_to = 'TestRoom3';
	e_to = 'TestRoom4';
};

Test_Room {
	nam = "TestRoom2",
	title = "Тестовая комната 2",
	s_to = 'TestRoom1';
};

Test_Room {
	nam = "TestRoom3",
	title = "Тестовая комната 3",
	n_to = 'TestRoom1';
};

Test_Room {
	nam = "TestRoom4",
	title = "Тестовая комната 4",
	w_to = 'TestRoom1';
};

Test_Object {
	-"куб";
	nam = "cube";
	found_in = {'TestRoom1'};
	size = rnd(7);
	weight = rnd(6);
	sound = rnd(3);
	smell = rnd(2);
	-- proximity = rnd(2,3);
};

Test_Object {
	-"шар";
	nam = "sphere";
	found_in = {'TestRoom1'};
	size = rnd(7);
	weight = rnd(6);
	sound = rnd(3);
	smell = rnd(2);
	-- proximity = rnd(2,3);
};

Test_Object {
	-"конус";
	nam = "cone";
	found_in = {'TestRoom1'};
	size = rnd(7);
	weight = rnd(6);
	sound = rnd(3);
	smell = rnd(2);
	-- proximity = rnd(2,3);
};

Test_Object {
	-"рельсы";
	nam = "rails";
	found_in = {'TestRoom2'};
	size = SIZE.BIG;
	weight = WEIGHT.HEAVIER;
	proximity = PROXIMITY.CLOSE;
}:attr 'supporter, enterable';

Test_Object {
	-"вагонетка";
	nam = "trolley";
	found_in = {'rails'};
	size = SIZE.MEDIUM;
	weight = WEIGHT.HEAVY;
	proximity = PROXIMITY.NEAR;
}:attr 'container, open, enterable, transparent';

Test_Object {
	-"баскетбольный щит,баскетбольный,щит";
	nam = "backboard";
	found_in = {'TestRoom3'};
	size = SIZE.MEDIUM;
	weight = WEIGHT.LIGHT;
	proximity = PROXIMITY.NEAR;
	after_Walk = function (s, w)
		return false;
	end;
	obj = {
		Test_Object {
			-"баскетбольное кольцо,баскетбольное,кольцо";
			nam = "test_ring";
			size = SIZE.MEDIUM;
			weight = WEIGHT.LIGHT;
			proximity = PROXIMITY.NEAR;
			after_Walk = function (s, w)
				return false;
			end;
			after_LetIn = function (s, w)
				move(w, here());
				return false;
			end
		}:attr 'container, open, transparent';
	}
}:attr 'transparent';

Test_Object {
	-"баскетбольный мяч,баскетбольный,мяч";
	nam = "ball";
	found_in = {'TestRoom3'};
	size = SIZE.MEDIUM;
	weight = WEIGHT.LIGHT;
};

Test_Object {
	-"солнце";
	nam = "sun";
	found_in = {'TestRoom4'};
	size = SIZE.ENORMOUS;
	weight = WEIGHT.TOOHEAVY;
	proximity = PROXIMITY.TOOFAR;
};

Test_Object {
	-"дождь";
	nam = "test_rain";
	found_in = {'TestRoom4'};
	size = SIZE.LARGE;
	weight = WEIGHT.TOOHEAVY;
	sound = SOUND.LOUD;
	smell = SMELL.SMELLY;
	proximity = PROXIMITY.AROUND;
}:attr 'drinkable, enterable';
