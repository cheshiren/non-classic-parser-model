
-- Новые или расширенные глаголы

-- Помахать кому-нибудь
VerbExtend {"#Wave",
	"{noun}/дт : WaveHands"
}


-- Переключение времени с настоящего на прошлое и обратно
Verb {
	"#Time",
	"_время",
	"Time",
}

function mp:Time()
	if me().time == "прш" then
		me().time = "нст";
		p("НАСТОЯЩЕЕ");
	else
		me().time = "прш"
		p("ПРОШЕДШЕЕ");
	end
end

-- Переключение вывода статистики
Verb {
	"#Stat",
	"_стат",
	"Stat",
}

function mp:Stat()       
	if me().stat then
		me().stat = false;
		p("СТАТИСТИКА ВЫКЛ");
	else
		me().stat = true;
		p("СТАТИСТИКА ВКЛ");
	end
end


-- ^^
Verb {
   "#Xyzzy",
   "xyzzy",
   "Xyzzy"
}

mp.msg.Xyzzy = {}
function mp:Xyzzy()       
  p(mp.msg.Xyzzy.Xyzzy);
end
mp.msg.Xyzzy.Xyzzy = ""


-- About
Verb {
   "#Info",
   "инфо, информация, аннотация, предисловие",
   "Info"
}

mp.msg.Info = {}
function mp:Info()       
  p("");
end
Verb ({'#Info', "инфо, информация, аннотация, предисловие", "Info" }, mp.cutscene)