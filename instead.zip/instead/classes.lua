
-- Новые классы

-- Класс для абстрактных вещей
Abstract = Class {
--"существовать"
--"знать"
	before_Default = function (s, ev, w)
		if ev ~= 'Exam' then
			return [[Для меня ]]..s:noun('им')..[[ в тот момент {#word/существовать,#first,прш} только как концепция.]]
		else
			s:attr'seen';							-- объект осмотрен
			return [[{#Me} не {#word/видеть,#me,#time} {#first/вн}, но {#word/знать,#me,#time}, что {#firstit} где-то там {#word/быть,#first,#time}.]];
		end
	end
}:attr 'persist, concealed';

-- Основной класс с заданными характеристиками и проверкой их перед каждым глаголом
Generic = Class {

	size = SIZE.SMALL;
	weight = WEIGHT.LIGHT;
	sound = SOUND.QUIET;
	smell = SMELL.NONSMELLY;
	proximity = PROXIMITY.CLOSE;

	before_Default = function(s, ev, w)
		-- p(ev);
		return check_verb(s, ev);
	end,
	life_Default = function(s, ev, w)
		-- p(ev);
		if s:has'animate' then
			return check_verb(s, ev);
		else
			return false;
		end
	end,
	['after_Enter,Exit'] = function (s, w)
		if std.me():where() == s and s.proximity ~= PROXIMITY.AROUND then
			s.proximity = PROXIMITY.AROUND;
		elseif std.me():where() ~= s and s.proximity == PROXIMITY.AROUND then
			s.proximity = PROXIMITY.CLOSE;
		end
		return false;
	end,
	post_Any = function(s, ev)
		if ev == 'Exam' or ev == 'LookUnder' or ev == 'LookAt' then
			s:attr'seen';							-- объект осмотрен
		end
		return false;
	end
}:attr 'concealed';

-- Класс для тех объектов, которые видны за лобовым стеклом
BehindWindshield = Class ({
	_description = "";
	description = function (s)
		if _'windshield':hasnt'transparent' then
			return [[Я едва видел ]] .. s:noun('вн') .. [[ за дождём, заливающим лобовое стекло — дворники были выключены.]]
		else
			if type(s._description) == "function" then
				return s:_description();
			else
				return s._description;
			end
		end
	end
}, Generic)
