-- Требуемые свойства объектов для каждого глагола + сообщение при неудаче
-- Так же см. https://disk.yandex.ru/edit/disk/disk%2F200.xlsx?source=docs
global 'verb_map' ({
	Enter = {
		Attributes = {'enterable'},
		Size = {0, 0, 1, 1, 1, 1, 0},
		Proximity = {0, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Enter.IMPOSSIBLE;
		AroundMsg = mp.msg.Enter.AROUND;
		TooFarMsg = mp.msg.Enter.TOOFAR;
	},
	Walk = {
		Size = {1, 1, 1, 1, 1, 1, 0},
		Proximity = {0, 0, 1, 1, 0, 0},
		NoMsg = mp.msg.Walk.IMPOSSIBLE;
		AroundMsg = mp.msg.Walk.AROUND;
		TooCloseMsg = mp.msg.Walk.TOOCLOSE;
	},
	Exit = {
		Attributes = {'enterable'},
		Size = {0, 0, 1, 1, 1, 1, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Enter.IMPOSSIBLE;
		TooFarMsg = mp.msg.Enter.TOOFAR;
	},
	Open = {
		-- Attributes = {'openable'},
		Size = {1, 1, 1, 1, 0, 0, 0},
		Weight = {1, 1, 1, 1, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Open.NOTOPENABLE;
	},
	Close = {
		-- Attributes = {'openable'},
		Size = {1, 1, 1, 1, 0, 0, 0},
		Weight = {1, 1, 1, 1, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Close.NOTOPENABLE;
	},
	Lock = {
		-- Attributes = {'lockable'},
		Size = {0, 1, 1, 1, 1, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Lock.IMPOSSIBLE;
	},
	Unlock = {
		-- Attributes = {'lockable'},
		Size = {0, 1, 1, 1, 1, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Unlock.IMPOSSIBLE;
	},
	Take = {
		Size = {1, 1, 1, 0, 0, 0, 0},
		Weight = {1, 1, 1, 0, 0, 0},
		Proximity = {0, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Take.IMPOSSIBLE;
	},
	Remove = {
		Size = {1, 1, 1, 0, 0, 0, 0},
		Weight = {1, 1, 1, 0, 0, 0},
		Proximity = {0, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Remove.IMPOSSIBLE;
	},
	Drop = {
		Size = {1, 1, 1, 0, 0, 0, 0},
		Weight = {1, 1, 1, 0, 0, 0},
		Proximity = {0, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Drop.IMPOSSIBLE;
	},
	Insert = {
		Size = {1, 1, 1, 0, 0, 0, 0},
		Weight = {1, 1, 1, 0, 0, 0},
		Proximity = {0, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Insert.IMPOSSIBLE;
	},
	PutOn = {
		Size = {1, 1, 1, 0, 0, 0, 0},
		Weight = {1, 1, 1, 0, 0, 0},
		Proximity = {0, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.PutOn.NOTSUPPORTER;
	},
	Recieve = {
		Size = {0, 1, 1, 1, 1, 1, 1},
		Proximity = {1, 1, 1, 0, 0, 0},
	},
	LetIn = {
		Size = {0, 1, 1, 1, 1, 1, 1},
		Proximity = {1, 1, 1, 0, 0, 0},
	},
	ThrowAt = {
		Size = {1, 1, 1, 0, 0, 0, 0},
		Weight = {1, 1, 0, 0, 0, 0},
		Proximity = {0, 1, 1, 0, 0, 0},
		NoMsg = mp.msg.ThrowAt.IMPOSSIBLE;
	},
	ThrownAt = {
		Proximity = {1, 1, 1, 0, 0, 0},
		NoMsg = mp.msg.ThrowAt.IMPOSSIBLE;
	},
	Wear = {
		Size = {1, 1, 1, 0, 0, 0, 0},
		Weight = {1, 1, 1, 0, 0, 0},
		Proximity = {0, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Wear.IMPOSSIBLE;
	},
	Disrobe = {
		Size = {1, 1, 1, 0, 0, 0, 0},
		Weight = {1, 1, 1, 0, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Disrobe.IMPOSSIBLE;
	},
	Listen = {
		Sound = {0, 1, 1},
		Proximity = {1, 1, 1, 1, 0, 0},
		NoMsg = mp.msg.Listen.IMPOSSIBLE;
		NoSoundMsg = mp.msg.Listen.NOSOUND;
	},
	Smell = {
		Smell = {0, 1},
		Proximity = {1, 1, 1, 0, 0, 0},
		NoMsg = mp.msg.Smell.IMPOSSIBLE;
		NoSmellMsg = mp.msg.Smell.NOSMELL;
	},
	SwitchOn = {
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.SwitchOn.NONSWITCHABLE;
	},
	SwitchOff = {
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.SwitchOff.NONSWITCHABLE;
	},
	Search = {
		Size = {1, 1, 1, 1, 0, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Search.IMPOSSIBLE;
	},
	LookUnder = {
		Size = {1, 1, 1, 1, 0, 0, 0},
		Proximity = {0, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.LookUnder.IMPOSSIBLE;
	},
	Eat = {
		Attributes = {'edible'},
		Size = {1, 1, 1, 0, 0, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Eat.NOTEDIBLE;
	},
	Taste = {
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Taste.IMPOSSIBLE;
	},
	Drink = {
		Attributes = {'drinkable'},
		-- Size = {1, 1, 1, 0, 0, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Drink.NOTDRINKABLE;
	},
	PushDir = {
		Size = {1, 1, 1, 1, 0, 0, 0},
		Weight = {1, 1, 1, 1, 0, 0},
		Proximity = {0, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.PushDir.PUSH;
	},
	Push = {
		Size = {1, 1, 1, 1, 0, 0, 0},
		Weight = {1, 1, 1, 1, 0, 0},
		Proximity = {0, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Push.SCENERY;
	},
	Pull = {
		Size = {1, 1, 1, 1, 0, 0, 0},
		Weight = {1, 1, 1, 1, 0, 0},
		Proximity = {0, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Pull.SCENERY;
	},
	Turn = {
		Size = {1, 1, 1, 0, 0, 0, 0},
		Weight = {1, 1, 1, 1, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Turn.SCENERY;
	},
	Rub = {
		Size = {1, 1, 1, 1, 0, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Rub.RUB;
	},
	Touch = {
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Touch.IMPOSSIBLE
	},
	Give = {
		Size = {1, 1, 1, 0, 0, 0, 0},
		Weight = {1, 1, 1, 0, 0, 0},
		Proximity = {0, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Give.IMPOSSIBLE;
	},
	Show = {
		Size = {1, 1, 1, 0, 0, 0, 0},
		Proximity = {0, 1, 1, 0, 0, 0},
		NoMsg = mp.msg.Show.IMPOSSIBLE;
	},
	Burn = {
		Attributes = {'combustable'},
		Size = {1, 1, 1, 1, 1, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Burn.IMPOSSIBLE;
	},
	WakeOther = {
		Size = {1, 1, 1, 1, 0, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.WakeOther.IMPOSSIBLE;
	},
	Kiss = {
		Size = {1, 1, 1, 1, 0, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Kiss.IMPOSSIBLE;
	},
	Dig = {
		Attributes = {'diggable'},
		Size = {0, 0, 1, 1, 1, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Dig.IMPOSSIBLE;
	},
	Cut = {
		Attributes = {'breakable'},
		Size = {0, 1, 1, 1, 1, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Cut.IMPOSSIBLE;
	},
	Tear = {
		Attributes = {'breakable'},
		Size = {0, 1, 1, 1, 1, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Tear.IMPOSSIBLE;
	},
	Tie = {
		Size = {0, 1, 1, 1, 1, 0, 0},
		Proximity = {0, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Tie.IMPOSSIBLE;
	},
	Blow = {
		Size = {1, 1, 1, 0, 0, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Blow.IMPOSSIBLE;
	},
	Attack = {
		Size = {0, 1, 1, 1, 1, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Attack.IMPOSSIBLE;
	},
	Consult = {
		Size = {1, 1, 1, 0, 0, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Consult.CONSULT;
	},
	Fill = {
		Size = {0, 1, 1, 1, 1, 0, 0},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Fill.IMPOSSIBLE;
	},
	JumpOver = {
		Size = {1, 1, 1, 0, 0, 0, 0},
		Proximity = {0, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.JumpOver.IMPOSSIBLE;
	},
	Wave = {
		Size = {1, 1, 1, 0, 0, 0, 0},
		Weight = {1, 1, 1, 0, 0, 0},
		Proximity = {0, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Wave.IMPOSSIBLE;
	},
	Talk = {
		Proximity = {1, 1, 1, 0, 0, 0},
		NoMsg = mp.msg.Talk.IMPOSSIBLE;
	},
	Tell = {
		Proximity = {1, 1, 1, 0, 0, 0},
		NoMsg = mp.msg.Tell.IMPOSSIBLE;
	},
	Ask = {
		Proximity = {1, 1, 1, 0, 0, 0},
		NoMsg = mp.msg.Ask.IMPOSSIBLE;
	},
	Answer = {
		Proximity = {1, 1, 1, 0, 0, 0},
		NoMsg = mp.msg.Answer.IMPOSSIBLE;
	},
	Use = {
		-- Attributes = {'usable'},
		-- Size = {1, 1, 1, 1, 0, 0, 0},
		Size = {0, 0, 1, 1, 1, 1, 1},
		Proximity = {1, 1, 0, 0, 0, 0},
		NoMsg = mp.msg.Use.USE;
	}
})
