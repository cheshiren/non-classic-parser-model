
-- Дополнительные библиотечные сообщения

mp.msg.IMPOSSIBLE = "Для {#first/рд} это {#if_time/прш,было} невозможно"
mp.msg.TOOFAR = mp.msg.IMPOSSIBLE .. " — слишком далеко."
mp.msg.TOOFARHEAVY = mp.msg.IMPOSSIBLE .. " — слишком далеко. Кроме того, {#firstit} {#if_time/прш,{#word/быть,#first,#time}} слишком {#word/тяжёлый,#first}."
mp.msg.TOOFARHEAVYBIG = mp.msg.IMPOSSIBLE .. " — слишком далеко. Кроме того, {#firstit} {#if_time/прш,{#word/быть,#first,#time}} слишком {#word/тяжёлый,#first} и {#word/большой,#first}."
mp.msg.TOOFARHEAVYSMALL = mp.msg.IMPOSSIBLE .. " — слишком далеко. Кроме того, {#firstit} {#if_time/прш,{#word/быть,#first,#time}} слишком {#word/тяжёлый,#first} и {#word/маленький,#first}."
mp.msg.TOOFARBIG = mp.msg.IMPOSSIBLE .. " — слишком далеко. Кроме того, {#firstit} {#if_time/прш,{#word/быть,#first,#time}} слишком {#word/большой,#first}."
mp.msg.TOOFARSMALL = mp.msg.IMPOSSIBLE .. " — слишком далеко. Кроме того, {#firstit} {#if_time/прш,{#word/быть,#first,#time}} слишком {#word/маленький,#first}."
mp.msg.TOOHEAVY = mp.msg.IMPOSSIBLE .. " — слишком {#word/тяжёлый,#first}."
mp.msg.TOOHEAVYBIG = mp.msg.IMPOSSIBLE .. " — слишком {#word/тяжёлый,#first} и слишком {#word/большой,#first}."
mp.msg.TOOHEAVYSMALL = mp.msg.IMPOSSIBLE .. " — слишком {#word/тяжёлый,#first} и слишком {#word/маленький,#first}."
mp.msg.TOOBIG = mp.msg.IMPOSSIBLE .. " — слишком {#word/большой,#first}."
mp.msg.TOOSMALL = mp.msg.IMPOSSIBLE .. " — слишком {#word/маленький,#first}."
mp.msg.AROUND = mp.msg.IMPOSSIBLE .. ". {#Me} {#word/находиться,#me,#time} внутри {#firstit/рд}."
mp.msg.TOOCLOSE = mp.msg.IMPOSSIBLE .. " — слишком близко."
mp.msg.TOOLIGHT = mp.msg.IMPOSSIBLE .. " — слишком {#word/лёгкий,#first}."



-- Переопределение библиотечных сообщений + добавление новых для реакций на различные свойства

mp.msg.SCENE = "{#Me} {#word/находиться,#me,#time} {#if_has/#here,supporter,на,в} {#here/пр,2}.";
mp.msg.INSIDE_SCENE = "{#Me} {#word/находиться,#me,#time} {#if_has/#where,supporter,на,в} {#where/пр,2}.";
mp.msg.TITLE_INSIDE = "{#if_has/#where,supporter,на,в} {#where/пр,2}";

mp.msg.Exam.DEFAULT = "{#Me} не {#word/видеть,#me,#time} {#vo/{#first/пр}} ничего необычного.";
mp.msg.Exam.SWITCHSTATE = "{#First} {#if_time/прш,{#word/быть,#first,#time}} {#if_has/#first,on,{#word/включён,#first},{#word/выключен,#first}}."

mp.msg.EXITBEFORE1 = "Возможно, {#me/дт} сначала нужно {#if_time/прш,было} {#if_has/#where,supporter,слезть с {#where/рд},покинуть {#where/вн}} или, хотя бы, открыть окно."
mp.msg.EXITBEFORE2 = "Возможно, {#me/дт} сначала нужно {#if_time/прш,было} {#if_has/#where,supporter,слезть с {#where/рд},покинуть {#where/вн}}."
mp.msg.EXITBEFORE = mp.msg.EXITBEFORE1; -- использовать реакцию для первой сцены В машине

mp.msg.ACCESS1 = "{#First} {#if_time/прш,{#word/быть,#first,#time}} не{#word/доступен,#first}."
mp.msg.ACCESS2 = "{#Second} {#if_time/прш,{#word/быть,#second,#time}} не{#word/доступен,#second}."

mp.msg.Inv.NOTHING = "У {#me/рд} с собой ничего {#if_time/прш,не было,нет}."
mp.msg.Inv.INV = "У {#me/рд} с собой {#if_time/прш,было}"

mp.msg.Enter.ALREADY = "{#Me} уже {#if_time/прш,{#word/быть,#me,#time}} {#if_has/#first,supporter,на,в} {#first/пр,2}."
mp.msg.Enter.INV = "{#Me} не {#word/могу,#me,#time} зайти в то, что {#word/держать,#me,#time} в руках."
mp.msg.Enter.IMPOSSIBLE = "Но в/на {#first/вн} невозможно {#if_time/прш,было} войти, встать, сесть или лечь."
mp.msg.Enter.CLOSED = "{#First} {#if_time/прш,{#word/быть,#first,#time}} {#word/закрыт,#first}, и {#me} не {#word/мочь,#me,#time} зайти туда."
mp.msg.Enter.ENTERED = "{#Me} {#if_time/нст,{#word/залезать,#me,#time},{#word/залезть,#me,#time}} {#if_has/#first,supporter,на,в} {#first/вн}."
mp.msg.Enter.DOOR_NOWHERE = "{#First} никуда не {#if_time/нст,ведёт,{#word/вести,#first,#time}}."
mp.msg.Enter.DOOR_CLOSED = "{#First} {#if_time/прш,{#word/быть,#first,#time}} {#word/закрыт,#first}."
mp.msg.Enter.EXITBEFORE = "Сначала {#me/дт} бы пришлось {#if_has/#where,supporter,слезть с {#where/рд}.,покинуть {#where/вн}.}"
mp.msg.Enter.AROUND = "Нельзя {#if_time/прш,было} попасть в то, внутри чего {#me} уже {#word/находиться,#me,#time}."
mp.msg.Enter.TOOFAR = "{#First} {#if_time/прш,{#word/быть,#first,#time}} слишком далеко для этого."

-- mp.msg.Walk.WALK = "Но {#first} и так {#word/находиться,#time,#first} рядом."
mp.msg.Walk.WALK = "{#Me} {#if_time/нст,{#word/подходить,#me,#time},{#word/подойти,#me,#time}} к {#first/дт}."
mp.msg.Walk.IMPOSSIBLE = "Это {#if_time/прш,было} невозможно."
mp.msg.Walk.AROUND = mp.msg.Walk.IMPOSSIBLE .. " {#Me} уже {#word/находиться,#me,#time} {#if_has/#where,supporter,на {#first/пр},внутри {#first/рд}}."
mp.msg.Walk.TOOCLOSE = "Но {#first} и так {#word/находиться,#time,#first} рядом."

mp.msg.Exit.NOTHERE = "Но {#me} {#if_time/нст,сейчас,тогда} не {#if_time/прш,{#word/быть,#me,#time}} {#if_has/#first,supporter,на,в} {#first/пр,2}."
mp.msg.Exit.NOWHERE = "Но {#me/дт} некуда {#if_time/прш,было} выходить."
mp.msg.Exit.CLOSED = "Но {#first} {#if_time/прш,{#word/быть,#first,#time}} {#word/закрыт,#first}."
mp.msg.Exit.EXITED = "{#Me} {#if_has/#first,supporter,{#if_time/нст,{#word/слезать,#me,#time},{#word/слезть,#me,#time}} {#so/{#first/рд}},{#if_time/нст,{#word/покидать,#me,#time},{#word/покинуть,#me,#time}} {#first/вн}}."

mp.msg.GetOff.NOWHERE = "Но {#me/дт} не с чего {#if_time/прш,было} слезать."

-- mp.msg.Open.OPEN = "{#Me} {#word/открыть,#me,#time} {#first/вн}."
mp.msg.Open.OPEN = "{#Me} {#if_time/нст,{#word/открывать,#me,#time},{#word/открыть,#me,#time}} {#first/вн}."
mp.msg.Open.NOTOPENABLE = "{#First/вн} невозможно {#if_time/прш,было} открыть."
mp.msg.Open.WHENOPEN = "{#First/} уже {#if_time/прш,{#word/быть,#first,#time}} {#word/открыт,#first}."

mp.msg.Close.CLOSE = "{#Me} {#if_time/нст,{#word/закрывать,#me,#time},{#word/закрыть,#me,#time}} {#first/вн}."
mp.msg.Close.NOTOPENABLE = "{#First/вн} невозможно {#if_time/прш,было} закрыть."
mp.msg.Close.WHENCLOSED = "{#First/} уже {#word/быть,#first,#time} {#word/закрыт,#first}."

mp.msg.Lock.IMPOSSIBLE = "{#First/вн} невозможно {#if_time/прш,было} запереть."
mp.msg.Unlock.IMPOSSIBLE = "{#First/вн} невозможно {#if_time/прш,было} отпереть."

mp.msg.Take.IMPOSSIBLE = "Нет, взять {#first/вн} {#if_time/прш,было} нельзя."
mp.msg.Take.HAVE = "У {#me/вн} и так {#firstit} уже {#word/быть,#first,#time}."
mp.msg.Take.TAKE = "{#Me} {#if_time/нст,{#word/брать,#me,#time},{#word/взять,#me,#time}} {#first/вн}."
mp.msg.Take.SELF = "{#Me} {#word/быть,#me,#time} у {#me/рд}."
mp.msg.Take.WHERE = "Нельзя {#if_time/прш,было} взять то, {#if_hint/#where,supporter,на,в} чём {#me} {#word/находиться,#me,#time}."
mp.msg.Take.LIFE = "{#First/дт} это вряд ли бы понравилось."
mp.msg.Take.STATIC = "{#First} {#if_time/прш,{#word/быть,#first,#time}} жёстко {#word/закреплён,#first}."
mp.msg.Take.SCENERY = "{#First/вн} невозможно {#if_time/прш,было} взять."
mp.msg.Take.WORN = "{#First} {#if_time/прш,{#word/быть,#first,#time}} {#word/надет,#first} на {#firstwhere/вн}."
mp.msg.Take.PARTOF = "{#First} {#word/являться,#first,#time} частью {#firstwhere/рд}."

mp.msg.Remove.IMPOSSIBLE = "Нет, извлечь {#first/вн} {#if_time/прш,было} нельзя."

mp.msg.Drop.DROP = "{#First} {#if_time/прш,{#word/быть,#first,#time}} {#word/брошен,#first}."
mp.msg.Drop.IMPOSSIBLE = "Нет, бросить {#first/вн} {#if_time/прш,было} нельзя."

mp.msg.Insert.IMPOSSIBLE = "Помещать {#first/вн} {#vo/{#second/вн}} {#if_time/прш,было} бессмысленно."
mp.msg.Insert.INSERT = "{#Me} {#if_time/нст,{#word/помещать,#me,#time},{#word/поместить,#me,#time}} {#first/вн} в {#second/вн}."
mp.msg.Insert.CLOSED = "{#Second} {#if_time/прш,{#word/быть,#second,#time}} {#word/закрыт,#second}."
mp.msg.Insert.NOTCONTAINER = "{#Second} не {#word/мочь,#second,#time} что-либо содержать."
mp.msg.Insert.WHERE = "Нельзя {#if_time/прш,было} поместить {#first/вн} внутрь себя."
mp.msg.Insert.ALREADY = "Но {#first} уже и так {#word/находиться,#first,#time} там."

mp.msg.PutOn.NOTSUPPORTER = "Класть что-либо на {#second/вн}  {#if_time/прш,было} бессмысленно."

mp.msg.ThrowAt.NOTLIFE = "Бросать {#first/вн} в {#second/вн} {#if_time/прш,было} бесполезно."
mp.msg.ThrowAt.THROW = "У {#me/рд} не {#if_time/нст,хватает,хватало} решимости бросить {#first/вн} в {#second/вн}."
mp.msg.ThrowAt.IMPOSSIBLE = "Бросать {#first/вн} в {#second/вн} {#if_time/прш,было} бессмысленно."

mp.msg.Wear.NOTCLOTHES = "Надеть {#first/вн} {#if_time/прш,было} невозможно."
mp.msg.Wear.WORN = "{#First} уже {#if_time/прш,{#word/быть,#first,#time}} на {#me/дт}."
mp.msg.Wear.WEAR = "{#Me} {#word/надеть,#me,#time } {#first/вн}."
mp.msg.Wear.IMPOSSIBLE = mp.msg.Wear.NOTCLOTHES

mp.msg.Disrobe.NOTWORN = "Но {#first} не {#if_time/прш,{#word/быть,#first,#time}} {#word/надет,#first}."
mp.msg.Disrobe.DISROBE = "{#Me} {#word/снять,#me,#time} {#first/вн}."
mp.msg.Disrobe.IMPOSSIBLE = "Снять {#first/вн} {#if_time/прш,было} невозможно."

mp.msg.Smell.SMELL = "Никакого необычного запаха {#if_time/прш,не было,нет}."
mp.msg.Smell.NOSMELL = "{#First} совершенно ничем не {#word/пахнуть,#first,#time}."
mp.msg.Smell.IMPOSSIBLE = "Нюхать {#first/вн} {#if_time/прш,было} нельзя."

mp.msg.Listen.LISTEN = "Никаких необычных звуков {#if_time/прш,не было,нет}."
mp.msg.Listen.LISTEN2 = "{#Me} {#word/прислушаться,#me,прш} к {#first/дт}. Никаких необычных звуков {#if_time/прш,не было,нет}."
mp.msg.Listen.IMPOSSIBLE = "Ничего особенного от {#first/рд} {#me} не {#word/слышать,#me,#time}."
mp.msg.Listen.NOSOUND = "Абсолютная тишина."

mp.msg.SwitchOn.NONSWITCHABLE = "{#First/вн} невозможно {#if_time/прш,было} включить."
mp.msg.SwitchOn.ALREADY = "{#First} уже {#if_time/прш,{#word/быть,#first,#time}} {#word/включён,#first}."
mp.msg.SwitchOn.SWITCHON = "{#Me} {#word/включать,#me,#time} {#first/вн}."

mp.msg.SwitchOff.NONSWITCHABLE = "{#First/вн} невозможно {#if_time/прш,было} выключить."
mp.msg.SwitchOff.ALREADY = "{#First} уже {#if_time/прш,{#word/быть,#first,#time}} {#word/выключен,#first}."
mp.msg.SwitchOff.SWITCHOFF = "{#Me} {#word/выключать,#me,#time} {#first/вн}."

mp.msg.Search.IMPOSSIBLE = "Исследовать {#first/вн} {#if_time/прш,было} невозможно."

mp.msg.LookUnder.NOTHING = "{#Me} не {#if_time/нст,{#word/находить,#me,#time},{#word/найти,#me,#time}} под {#first/тв} ничего интересного."
mp.msg.LookUnder.IMPOSSIBLE = "Заглянуть под {#first/вн} {#if_time/прш,было} невозможно."

mp.msg.Eat.NOTEDIBLE = "{#First} не {#word/годиться,#first,#time} в пищу."
mp.msg.Eat.EAT = "{#Me} {#if_time/нст,{#word/есть,#me,#time},{#word/поесть,#me,#time}} {#first/вн}."
mp.msg.Eat.IMPOSSIBLE = "Есть {#first/вн} {#if_time/прш,было} невозможно."
mp.msg.Taste.TASTE = "Никакого необычного вкуса {#if_time/прш,не было,нет}."
mp.msg.Taste.IMPOSSIBLE = "Пробовать {#first/вн} {#if_time/прш,было} невозможно."
mp.msg.Drink.NOTDRINKABLE = "{#First} не {#word/годиться,#first,#time} для питья."
mp.msg.Drink.DRINK = "{#Me} {#if_time/нст,{#word/пить,#me,#time},{#word/попить,#me,#time}} {#first/вн}."
mp.msg.Drink.IMPOSSIBLE = "Пить {#first/вн} {#if_time/прш,было} невозможно."

mp.msg.PushDir.PUSH = "Передвигать {#firstit/вн} {#if_time/прш,не имело,нет} смысла."

mp.msg.Push.STATIC = "{#First/вн} трудно {#if_time/прш,было} сдвинуть с места."
mp.msg.Push.SCENERY = "{#First/вн} двигать {#if_time/прш,было} невозможно."
mp.msg.Push.PUSH = "Ничего не произошло."

mp.msg.Pull.STATIC = "{#First/вн} трудно {#if_time/прш,было} сдвинуть с места."
mp.msg.Pull.SCENERY = "{#First/вн} двигать {#if_time/прш,было} невозможно."
mp.msg.Pull.PULL = "Ничего не произошло."

mp.msg.Turn.STATIC = "{#First/вн} трудно {#if_time/прш,было} сдвинуть с места."
mp.msg.Turn.SCENERY = "{#First/вн} двигать {#if_time/прш,было} невозможно."
mp.msg.Turn.TURN = "Ничего не произошло."

mp.msg.Wait.WAIT = "{#if_time/нст,Проходит,Прошло} немного времени."

mp.msg.Rub.RUB = "Тереть {#first/вн} {#if_time/прш,было} бессмысленно."

mp.msg.Sing.SING = "С таким слухом и голосом как у {#me/рд} этого лучше {#if_time/прш,было} не делать."

mp.msg.Touch.LIVE = "Не {#if_time/прш,стоило,стоит} давать волю рукам."
mp.msg.Touch.TOUCH = "Никаких необычных ощущений {#if_time/прш,не было,нет}."
mp.msg.Touch.MYSELF = "{#Me} {#if_time/прш,{#word/быть,#first,#time}} на месте."
mp.msg.Touch.IMPOSSIBLE = "{#First/вн} невозможно {#if_time/прш,было} коснуться."

mp.msg.Give.MYSELF = "{#First} и так у {#me/рд} уже {#if_time/прш,было,есть}."
mp.msg.Give.GIVE = "{#Second/вн} это не заинтересовало."
-- я не знаю почему, но в следующем сообщении second — это то, что передаётся, а first — это кому передаётся:
mp.msg.Give.IMPOSSIBLE = "Передать {#second/вн} {#first/дт} {#if_time/прш,было} невозможно."

mp.msg.Show.SHOW = "{#Second/вн} это не впечатлило."
mp.msg.Show.IMPOSSIBLE = "Показать {#first/вн} {#second/дт} {#if_time/прш,было} невозможно."

mp.msg.Burn.BURN = "Поджигать {#first/вн} {#if_time/прш,было} бессмысленно."
mp.msg.Burn.BURN2 = "Поджигать {#first/вн} {#second/тв} {#if_time/прш,было} бессмысленно."
mp.msg.Burn.IMPOSSIBLE = "Поджечь {#first/вн} {#if_time/прш,было} невозможно."

mp.msg.Wake.WAKE = "Это {#if_time/прш,был} не сон, а явь."
mp.msg.WakeOther.WAKE = "Будить {#first/вн} не {#if_time/прш,стоило,стоит}."
mp.msg.WakeOther.NOTLIVE = "Бессмысленно {#if_time/прш,было} будить {#first/вн}."
mp.msg.WakeOther.IMPOSSIBLE = "Будить {#first/вн} {#if_time/прш,было} невозможно."

mp.msg.Kiss.NOTLIVE = "Странное желание."
mp.msg.Kiss.KISS = "{#Firstit/дт} это {#if_time/прш,могло,может} не понравиться."
mp.msg.Kiss.MYSELF = "Ну уж нет."
mp.msg.Kiss.IMPOSSIBLE = "Поцеловать {#first/вн} {#if_time/прш,было} невозможно."

mp.msg.Dig.DIG = "{#Me} ничего не {#word/выкопать,#me,прш}."
mp.msg.Dig.DIG2 = "Копать {#first/вн} {#if_time/прш,было} бессмысленно."
mp.msg.Dig.DIG3 = "Копать {#first/вн} {#second/тв} {#if_time/прш,было} бессмысленно."
mp.msg.Dig.IMPOSSIBLE = "Копать {#first/вн} {#if_time/прш,было} невозможно."

mp.msg.Cut.CUT = "Резать {#first/вн} {#if_time/прш,было} бессмысленно."
mp.msg.Cut.CUT2 = "Резать {#first/вн} {#second/тв} {#if_time/прш,было} бессмысленно."
mp.msg.Cut.IMPOSSIBLE = "Резать {#first/вн} {#if_time/прш,было} невозможно."

mp.msg.Tear.TEAR = "Рвать {#first/вн} {#if_time/прш,было} бессмысленно."
mp.msg.Tear.IMPOSSIBLE = "Рвать {#first/вн} {#if_time/прш,было} невозможно."

mp.msg.Tie.TIE = "Привязывать {#first/вн} {#if_time/прш,было} бессмысленно."
mp.msg.Tie.TIE2 = "Привязывать {#first/вн} к {#second/дт} {#if_time/прш,было} бессмысленно."
mp.msg.Tie.IMPOSSIBLE = "Привязать {#first/вн} {#if_time/прш,было} невозможно."

mp.msg.Blow.BLOW = "Дуть на/в {#first/вн} {#if_time/прш,было} бессмысленно."
mp.msg.Blow.IMPOSSIBLE = "Дуть на/в {#first/вн} {#if_time/прш,было} невозможно."

mp.msg.Attack.LIFE = "Агрессия к {#first/дт} {#if_time/прш,была} неоправданна."
mp.msg.Attack.ATTACK = "Сила есть — ума не надо?"
mp.msg.Attack.IMPOSSIBLE = "Атаковать {#first/вн} {#if_time/прш,было} невозможно."

mp.msg.Sleep.SLEEP = "{#Me} не {#word/хотеть,#me,#time} спать."

mp.msg.Swim.SWIM = "Для этого {#if_time/прш,там было,здесь} недостаточно воды."

mp.msg.Consult.CONSULT = "{#Me} не {#if_time/нст,{#word/находить,#me,#time},{#word/найти,#me,#time}} ничего подходящего."

mp.msg.Fill.FILL = "Наполнять {#first/вн} {#if_time/прш,было} бессмысленно."
mp.msg.Fill.IMPOSSIBLE = "Наполнить {#first/вн} {#if_time/прш,было} невозможно."

mp.msg.Jump.JUMP = "{#Me} глупо {#if_time/нст,{#word/подпрыгивать,#me,#time},{#word/подпрыгнуть,#me,#time}}."

mp.msg.JumpOver.JUMPOVER = "Прыгать через {#first/вн} {#if_time/прш,было} бессмысленно."
mp.msg.JumpOver.IMPOSSIBLE = "Прыгать через {#first/вн} {#if_time/прш,было} невозможно."

mp.msg.Wave.IMPOSSIBLE = "Махать {#first/тв} {#if_time/прш,было} невозможно."

mp.msg.GetOff.NOWHERE = "Но {#me/дт} не с чего {#if_time/прш,было} слезать."

mp.msg.Buy.BUY = "{#First} не {#word/продаваться,#first,#time}."

mp.msg.Talk.NOTLIVE = "{#First} не {#word/уметь,#first,#time} разговаривать."
mp.msg.Talk.LIVE = "{#First} никак не {#word/отреагировать,#first,#time}."
mp.msg.Talk.IMPOSSIBLE = "Разговор с {#first/тв} {#if_time/прш,был} невозможен."

mp.msg.Tell.NOTLIVE = "{#First} {#if_time/прш,{#word/быть,#first,#time}} {#word/безмолвен,#first}."
mp.msg.Tell.LIVE = "{#First} никак не {#word/отреагировать,#first,#time}."
mp.msg.Tell.IMPOSSIBLE = "Разговор с {#first/тв} {#if_time/прш,был} невозможен."

mp.msg.Ask.IMPOSSIBLE = "Разговор с {#first/тв} {#if_time/прш,был} невозможен."

mp.msg.Answer.IMPOSSIBLE = "Разговор с {#first/тв} {#if_time/прш,был} невозможен."


-- Словарь
--"маленький"
--"большой"
--"лёгкий"
--"тяжёлый"
--"подойти"
--"открыть"
--"закрыть"
--"быть"
--"взять"
--"находиться"
--"закреплён"
--"надет"
--"являться"
--"поместить"
--"мочь"
--"надеть"
--"снять"
--"выключен"
--"найти"
--"годиться"
--"слышать"
--"подпрыгнуть"
--"пахнуть"
--"залезть"
--"слезть"
--"покинуть"
--"есть"
--"поесть"
--"пить"
--"попить"